import About from './components/About';
import Gallery from './components/Gallary';
import Home from './components/Home';
import Service from './components/Services';
import Navbar from './components/Navbar';
import { Route,Routes } from 'react-router-dom';
// import 'holderjs';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import { Icon1 } from "react-icons/fa";

function App() {
  
  return (
    <>
    <Navbar/>
    <div className='container'>
    {/* {component} */}
    <Routes>
      <Route path="/" element={<Home/>}>AiFillHome</Route>
      <Route path="/about" element={<About/>}></Route>
      <Route path='/service' element={<Service/>}></Route>
      <Route path="/gallery" element={<Gallery/>}></Route>
    </Routes>
    </div>
    </>
    
  );
}

export default App;
