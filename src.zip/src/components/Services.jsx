import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import '../css/styles.css';
import Accordion from 'react-bootstrap/Accordion';

function Service() {
   
  return (
    <div>
    <CardGroup  className='list'>
  
      <Card>
        <Card.Img variant="top" src="/images/prince2.png" />
        <Card.Body>
          <Card.Title>PRINCE2@</Card.Title>
          <Card.Text>
          PRINCE2® is a credible and prominent methodology that concentrates on boosting productivity and extracting the best from resources
          </Card.Text>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Last updated 3 mins ago</small>
        </Card.Footer>
      </Card>
      
      <Card>
        <Card.Img variant="top" src="/images/img10.png" />
        <Card.Body>
          <Card.Title>
ITIL®</Card.Title>
          <Card.Text>
          This ITIL 4 Foundation course is designed to give delegates a comprehensive understanding of the ITIL framework and its role in modern ITSM. This ITIL course covers the following
          </Card.Text>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Last updated 3 mins ago</small>
        </Card.Footer>
      </Card>
      <Card>
        
        <Card.Body>
          <Card.Title style={{color:"#5b2bd2"}}>Lean Six Sigma</Card.Title>
          <Card.Text>
          Lean Six Sigma (LSS) is a methodology used to improve business processes, based on the combination of two management ideologies, Lean and Six Sigma.
          </Card.Text>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Last updated 3 mins ago</small>
        </Card.Footer>
      </Card>
     
    </CardGroup>
    

    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0">
        <Accordion.Header style={{color:"#5b2bd2"}}>Maximum budget efficiency</Accordion.Header>
        <Accordion.Body style={{color:"#5b2bd2"}}>
        Our training pass services allow you to take full control of your budget and get the most for your money.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header style={{color:"#5b2bd2"}}>Dedicated account manager</Accordion.Header>
        <Accordion.Body style={{color:"#5b2bd2"}}>
        Your on hand account manager is committed to delivering the best possible service.
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
    </div>
  );
  
}

export default Service;