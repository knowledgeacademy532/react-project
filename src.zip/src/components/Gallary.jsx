
import '../css/styles.css';
import {
  MDBCard,
  MDBCardImage,
  MDBRow,
  MDBCol
} from 'mdb-react-ui-kit';

function Gallary() {
  return (
    <MDBRow className='row-cols-1 row-cols-md-2 g-4'>
    <MDBCol>
      <MDBCard>
        <MDBCardImage
          src='/images/crm_training.jpg'
          alt='...'
          position='top'
        />
       
      </MDBCard>
    </MDBCol>
    <MDBCol>
      <MDBCard>
        <MDBCardImage
          src='/images/project-managemenr-goals.jpg'
          alt='...'
          position='top'
        />
       
      </MDBCard>
    </MDBCol>
    <MDBCol>
      <MDBCard>
        <MDBCardImage
          src='/images/img2.jpg'
          alt='...'
          position='top'
        />
        
      </MDBCard>
    </MDBCol>
    <MDBCol>
      <MDBCard>
        <MDBCardImage
          src='/images/img1.png'
          alt='...'
          position='top'
        />
       
      </MDBCard>
    </MDBCol>
  </MDBRow>

   
    
    
  );
}

export default Gallary;