import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from "react-router-dom"

function Navbar1() {
  return (
    <Navbar bg="primary" expand="lg" >
      <Container>
        <Navbar.Brand href="/" style={{color:"#6610f2"}}>TKA</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
          
          </Nav>
          <Nav>
            <Nav.Link href="/" style={{color:"white"}}>Home</Nav.Link>
            <Nav.Link href="/about" style={{color:"white"}}>About Us</Nav.Link>
            <Nav.Link href="/gallery" style={{color:"white"}}>Gallery</Nav.Link>
            <Nav.Link href="/service" style={{color:"white"}}>Services</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Navbar1;

