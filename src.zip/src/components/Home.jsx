
import Carousel from 'react-bootstrap/Carousel';
import React from "react";
import "../css/styles.css"

function Home() {
    return (
      <div>
      <Carousel>
        <Carousel.Item >
          <img
            className="d-block w-100"
            src="/images/project-managemenr-goals.jpg"
            alt="First slide"
            width="100%"
            height="600px"
            
          />
          <Carousel.Caption>
            <h3 >Transforming organisations and individuals across the world.</h3>
            <p></p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
           className="d-block w-100"
           src="/images/img1.png"
           alt="Second slide"
           width="100%"
           height="600px"
          />
  
          <Carousel.Caption>
            <h3 >Largest global course portfolio</h3>
            
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
             className="d-block w-100"
             src="/images/itil.jpg"
             alt="Third slide"
             width="100%"
             height="600px"
          />
  
          <Carousel.Caption>
            <h3>Multichannel delivery</h3>
            
          </Carousel.Caption>
        </Carousel.Item>
        
      </Carousel>
      <h2 style={{color:"#5b2bd2"}}>Largest global course portfolio</h2>
      <p style={{color:"orange"}}>   You won’t find better value in the marketplace. If you do find a lower price, we will beat it. </p>
      
      <h2 style={{color:"#5b2bd2"}}>Most venues globally</h2>
      <p style={{color:"orange"}}>  We have locations stretching the entire globe, allowing flexible training wherever you need it. </p>
     
      <h2 style={{color:"#5b2bd2"}}>Best choice of dates for classroom courses</h2>
      <p style={{color:"orange"}}>   A variety of delivery methods are available depending on your learning preference. </p>
     
      </div>
    );
    
  }
export default Home;