// import Button from 'react-bootstrap/Button';
// import Card from 'react-bootstrap/Card';

// function About() {
//   return (
//     <Card className='card1' >
//       <Card.Header>About us</Card.Header>
//       <Card.Body>
//         <Card.Title>Welcome to The Knowledge Academy</Card.Title>
//         <Card.Img variant="top" src="/images/img2.jpg" />
//         <Card.Text>
//         An awarded & globally established provider of training courses
//         </Card.Text>
//         <Card.Text>
//         globally, with extensive experience of providing quality-infused learning solutions 
//         </Card.Text>
//         <Card.Text>
//         with the capability to deliver over 30,000 courses, in 1000+ locations, across 190
//         </Card.Text>
//         <Card.Text>
//         countries. As market leaders, we have successfully trained over 1 million delegates
//         </Card.Text>
//         <Card.Text>
//         demonstrating our internationally-renowned trust and unrivalled premium
//         </Card.Text>
//         <Button variant="primary">Go somewhere</Button>
//       </Card.Body>
//     </Card>
//   );
// }

// export default About;
import React from 'react';
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBBtn
} from 'mdb-react-ui-kit';

export default function About() {
  return (
    <MDBCard>
      <MDBCardBody>
        <MDBCardTitle style={{color:"#5b2bd2"}}>Welcome to The Knowledge Academy</MDBCardTitle>
        <img
            className="d-block w-100"
            src="/images/img3.png"
            alt="First slide"
            width="100%"
         
            
          />
           <MDBCardText style={{color:"orange"}}>
           Over the course of the current health crisis we’ve adapted the way we work to allow our clients to continue getting the same great quality training, whilst in a safe environment. All of our courses are available as online instructor-led, you get the feel of a classroom course but from the comfort of your own home.
        </MDBCardText>
        <MDBCardText style={{color:"pink"}}>
        An awarded & globally established provider of training courses
        </MDBCardText>
        <MDBCardText>
        globally, with extensive experience of providing quality-infused learning solutions -
        </MDBCardText>
        <MDBCardText>
        with the capability to deliver over 30,000 courses, in 1000+ locations, across 190
        </MDBCardText>
        <MDBCardText>
        countries. As market leaders, we have successfully trained over 1 million delegates
        </MDBCardText>
        <MDBCardText>
        - demonstrating our internationally-renowned trust and unrivalled premiums
        </MDBCardText>
        <MDBBtn href='https://www.theknowledgeacademy.com/' style={{backgroundColor:"orange"}}>Read more</MDBBtn>
      </MDBCardBody>
    </MDBCard>
  );
}